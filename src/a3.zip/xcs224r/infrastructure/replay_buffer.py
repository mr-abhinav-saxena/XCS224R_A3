from xcs224r.infrastructure.utils import *
from typing import Any, Dict, List, Tuple, Union
import numpy as np


class ReplayBuffer(object):

    def __init__(self, max_size: int=1000000) -> None:

        self.max_size = max_size
        self.paths: List[Dict[str, np.ndarray]] = []
        self.obs: Any = None
        self.acs: Any = None
        self.concatenated_rews: Any = None
        self.unconcatenated_rews: Any = None
        self.next_obs: Any = None
        self.terminals: Any = None

    def add_rollouts(self, paths: List[Dict[str, Any]], noised: bool=False) -> None:

        # add new rollouts into our list of rollouts
        for path in paths:
            tpath = dict()
            # print (path.keys())
            tpath['observation'] = path['observations']
            tpath['next_observation'] = path['next_observations']
            tpath['reward'] = path['rewards']
            tpath['action'] = path['actions']
            tpath['terminal'] = path['terminals']
            self.paths.append(tpath)

        # convert new rollouts into their component arrays, and append them onto our arrays
        observations, actions, next_observations, terminals, concatenated_rews, unconcatenated_rews = convert_listofrollouts(self.paths)

        if noised:
            observations = add_noise(observations)
            next_observations = add_noise(next_observations)

        if self.obs is None:
            self.obs = observations[-self.max_size:]
            self.acs = actions[-self.max_size:]
            self.next_obs = next_observations[-self.max_size:]
            self.terminals = terminals[-self.max_size:]
            self.concatenated_rews = concatenated_rews[-self.max_size:]
            self.unconcatenated_rews = unconcatenated_rews[-self.max_size:]
        else:
            self.obs = np.concatenate([self.obs, observations])[-self.max_size:]
            self.acs = np.concatenate([self.acs, actions])[-self.max_size:]
            self.next_obs = np.concatenate(
                [self.next_obs, next_observations]
            )[-self.max_size:]
            self.terminals = np.concatenate(
                [self.terminals, terminals]
            )[-self.max_size:]
            self.concatenated_rews = np.concatenate(
                [self.concatenated_rews, concatenated_rews]
            )[-self.max_size:]
            if isinstance(unconcatenated_rews, list):
                self.unconcatenated_rews += unconcatenated_rews  # TODO keep only latest max_size around
            else:
                self.unconcatenated_rews.append(unconcatenated_rews)  # TODO keep only latest max_size around

        print (self.terminals.sum())
    ########################################
    ########################################

    def sample_random_rollouts(self, num_rollouts: int) -> List[Dict[str, np.ndarray]]:
        rand_indices = np.random.permutation(len(self.paths))[:num_rollouts]
        return [self.paths[i] for i in rand_indices]

    def sample_recent_rollouts(self, num_rollouts: int=1) -> List[Dict[str, np.ndarray]]:
        return self.paths[-num_rollouts:]

    def can_sample(self, batch_size: int) -> bool:
        # print (self.obs.shape[0])
        if self.obs is None:
            return False
        if self.obs.shape[0] > batch_size:
            return True
        else:
            return False

    ########################################
    ########################################

    def sample_random_data(self, batch_size: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:

        assert self.obs.shape[0] == self.acs.shape[0] == self.concatenated_rews.shape[0] == self.next_obs.shape[0] == self.terminals.shape[0]
        rand_indices = np.random.permutation(self.obs.shape[0])[:batch_size]
        return self.obs[rand_indices], self.acs[rand_indices], self.concatenated_rews[rand_indices], self.next_obs[rand_indices], self.terminals[rand_indices]

    def sample(self, batch_size: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        return self.sample_random_data(batch_size)
    
    def sample_recent_data(self, batch_size: int=1, concat_rew: bool=True) -> Tuple[np.ndarray, np.ndarray, Any, np.ndarray, np.ndarray]:

        if concat_rew:
            return self.obs[-batch_size:], self.acs[-batch_size:], self.concatenated_rews[-batch_size:], self.next_obs[-batch_size:], self.terminals[-batch_size:]
        else:
            num_recent_rollouts_to_return = 0
            num_datapoints_so_far = 0
            index = -1
            while num_datapoints_so_far < batch_size:
                recent_rollout = self.paths[index]
                index -=1
                num_recent_rollouts_to_return +=1
                num_datapoints_so_far += get_pathlength(recent_rollout)
            rollouts_to_return = self.paths[-num_recent_rollouts_to_return:]
            observations, actions, next_observations, terminals, concatenated_rews, unconcatenated_rews = convert_listofrollouts(rollouts_to_return)
            return observations, actions, unconcatenated_rews, next_observations, terminals
